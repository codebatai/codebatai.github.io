
# Evidence Package (Verifiable Demo)

This is a **self-contained, verifiable** demo package.
You can verify it offline with only Python 3 (no extra libraries).

## Files
- `manifest.json`      — core metadata
- `spct.jwt`, `hmat.jwt` — JWS tokens (HS256) signed with a demo key
- `jwks_demo.json`     — demo "JWKS" (shared secret published for verification)
- `event_log.ndjson`   — 10 demo events (each line is a leaf)
- `merkle.json`        — Merkle root + audit paths for each leaf
- `verify_evidence.py` — verifier (no dependencies)

## Verify (one command)
```bash
python3 verify_evidence.py .
```

You should see:
```
SPCT signature: OK
HMAT signature: OK
Merkle proofs: Merkle proofs OK

ALL CHECKS PASSED ✅
```

> Production note: in real deployments, SPCT/HMAT would be **asymmetric JWS** (ES256/EdDSA) with public keys via JWKS, and TSA/WORM receipts would be included. This demo focuses on **verifiability** without external infrastructure.
