#!/usr/bin/env sh
# run_verify.sh — cross-platform (Linux/macOS, Git Bash/WSL on Windows)
# It resolves the script directory and runs the Python verifier on that folder.

# Resolve script directory (works for spaces in path)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"

# Prefer python3, then python, then Windows launcher 'py -3'
if command -v python3 >/dev/null 2>&1; then
  exec python3 -u "$SCRIPT_DIR/verify_evidence.py" "$SCRIPT_DIR"
elif command -v python >/dev/null 2>&1; then
  exec python -u "$SCRIPT_DIR/verify_evidence.py" "$SCRIPT_DIR"
elif command -v py >/dev/null 2>&1; then
  exec py -3 -u "$SCRIPT_DIR/verify_evidence.py" "$SCRIPT_DIR"
else
  echo "Python 3 not found. Please install Python 3.x."
  exit 1
fi
