
#!/usr/bin/env python3
# verify_evidence.py — robust verifier (handles Windows quotes/backslashes)
import json, base64, hmac, hashlib, sys, os, traceback

def b64url_decode(s):
    s = s.encode() if isinstance(s, str) else s
    s += b'=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s)

def verify_jws_hs256(jwt, key_b64):
    header_b64, payload_b64, sig_b64 = jwt.split('.')
    signing = (header_b64 + "." + payload_b64).encode()
    key = b64url_decode(key_b64)
    mac = hmac.new(key, signing, hashlib.sha256).digest()
    return hmac.compare_digest(mac, b64url_decode(sig_b64))

def sha256_hex(b):
    return hashlib.sha256(b).hexdigest()

def merkle_parent(h1, h2):
    if h2 is None:
        h2 = h1
    return sha256_hex(bytes.fromhex(h1) + bytes.fromhex(h2))

def verify_merkle(source_path, merkle_json):
    with open(source_path, "rb") as f:
        lines = f.read().splitlines()
    leaves = [sha256_hex(line) for line in lines]
    if len(leaves) != merkle_json["leaf_count"]:
        return False, f"Leaf count mismatch: expected {merkle_json['leaf_count']}, got {len(leaves)}"
    claimed_root = merkle_json["root"].split(":")[1]
    for i, leaf in enumerate(leaves):
        path = merkle_json["audit_paths"][str(i)]
        h = leaf
        for step in path:
            pos = step["position"]
            sib = step["hash"].split(":")[-1] if ":" in step["hash"] else step["hash"]
            if pos == "right":
                h = merkle_parent(h, sib)
            elif pos == "left":
                h = merkle_parent(sib, h)
            elif pos == "self-dup":
                h = merkle_parent(h, None)
            else:
                return False, f"Unknown path position {pos}"
        if h != claimed_root:
            return False, f"Audit path failed at leaf {i}"
    return True, "Merkle proofs OK"

def sanitize_path(p):
    # Remove surrounding quotes and trailing stray quotes
    p = p.strip().strip('"').strip("'")
    # Normalize and collapse any .. or duplicated slashes
    return os.path.normpath(p)

def main(arg_path):
    print("=== Evidence Verifier (Demo) ===")
    pkg_dir = sanitize_path(arg_path or ".")
    print("Working dir:", pkg_dir)

    required = ["manifest.json","jwks_demo.json","spct.jwt","hmat.jwt","event_log.ndjson","merkle.json"]
    missing = []
    for name in required:
        path = os.path.join(pkg_dir, name)
        exists = os.path.exists(path)
        print(" -", name, "OK" if exists else "MISSING")
        if not exists: missing.append(name)

    if missing:
        print("\nHINT: Make sure you pass the path to the folder that contains these files.")
        print("  Examples:")
        print('    python -u verify_evidence.py .')
        print('    python -u verify_evidence.py "C:\\\\path\\\\to\\\\evidence_verified"')
        return 2

    # Load manifest & jwks
    with open(os.path.join(pkg_dir, "manifest.json"), "r", encoding="utf-8") as f:
        manifest = json.load(f)
    with open(os.path.join(pkg_dir, manifest["execution_attestation"]["jwks"]), "r", encoding="utf-8") as f:
        jwks = json.load(f)

    # Verify SPCT & HMAT
    with open(os.path.join(pkg_dir, manifest["execution_attestation"]["spct"]["file"]), encoding="utf-8") as f:
        spct = f.read().strip()
    with open(os.path.join(pkg_dir, manifest["execution_attestation"]["hmat"]["file"]), encoding="utf-8") as f:
        hmat = f.read().strip()

    print("\n[1/3] Verifying SPCT signature...", end=" ", flush=True)
    ok_spct = verify_jws_hs256(spct, jwks["k"])
    print("OK" if ok_spct else "FAIL")

    print("[2/3] Verifying HMAT signature...", end=" ", flush=True)
    ok_hmat = verify_jws_hs256(hmat, jwks["k"])
    print("OK" if ok_hmat else "FAIL")

    # Verify Merkle
    print("[3/3] Verifying Merkle proofs...", end=" ", flush=True)
    with open(os.path.join(pkg_dir, "merkle.json"), encoding="utf-8") as f:
        merkle_json = json.load(f)
    merkle_ok, merkle_msg = verify_merkle(os.path.join(pkg_dir, merkle_json["source_file"]), merkle_json)
    print(merkle_msg)

    if ok_spct and ok_hmat and merkle_ok:
        print("\nALL CHECKS PASSED ✅")
        return 0
    else:
        print("\nCHECKS FAILED ❌")
        return 1

if __name__ == "__main__":
    try:
        arg = sys.argv[1] if len(sys.argv) > 1 else "."
        sys.exit(main(arg))
    except Exception as e:
        print("ERROR:", e)
        traceback.print_exc()
        sys.exit(2)
